package Model;

public class Relatórios {

}
