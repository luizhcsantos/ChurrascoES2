package Model;

public class MultaPerda extends Multa {

	private int código;

	private String nome;

	private float valor;

	private String descrição;

	private boolean resolvida;

}
