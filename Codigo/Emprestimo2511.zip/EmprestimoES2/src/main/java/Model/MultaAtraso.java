package Model;

import java.util.Date;

public class MultaAtraso extends Multa {

	private int código;

	private Date data;

	private float valor;

	private String descrição;

	private boolean resolvida;

}
