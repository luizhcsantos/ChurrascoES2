package Model;

import java.util.Date;

public class MultaDano extends Multa {

	private int códgo;

	private Date data;

	private float valor;

	private String descrição;

	private boolean resolvida;

}
