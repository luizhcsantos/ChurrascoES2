package Model;

import java.util.Date;

public class Devolucao {

	private int código;

	private Date prazo_original;

	private Date data_confirmada;

	private String descrição_bem;

	private boolean confirmada;

}
