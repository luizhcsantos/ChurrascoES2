/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.churrasco.UI.Classes;

/**
 *
 * @author Microsoft
 */
public class CategoriaAlimentar {
    public static final String ONIVORO = "ONÍVORO";
    public static final String CARNIVORO = "CARNÍVORO";
    public static final String VEGETARIANO = "VEGETARIANO";
    public static final String VEGANO = "VEGANO";
}
