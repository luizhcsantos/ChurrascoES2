/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.churrasco.UI.Classes;

/**
 *
 * @author Microsoft
 */
public class TipoUsuario {
    public static final String ORGANIZADOR = "ORGANIZADOR";
    public static final String PERMANENTE = "PERMANENTE";
    public static final String CONVIDADO = "CONVIDADO";
}
