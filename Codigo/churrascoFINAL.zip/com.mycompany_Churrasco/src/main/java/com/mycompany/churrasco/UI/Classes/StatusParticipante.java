/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.churrasco.UI.Classes;

/**
 *
 * @author Microsoft
 */
public class StatusParticipante {
    public static final String CONFIRMADO = "CONFIRMADO";
    public static final String PENDENTE = "PENDENTE";
}
