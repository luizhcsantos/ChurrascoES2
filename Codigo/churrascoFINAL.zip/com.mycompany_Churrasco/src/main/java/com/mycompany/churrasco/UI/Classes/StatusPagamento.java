/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.churrasco.UI.Classes;

/**
 *
 * @author Microsoft
 */
public class StatusPagamento {
    public static final String ATIVO = "ATIVO";
    public static final String DEVEDOR = "DEVEDOR";
}
