/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.churrasco.UI.Classes;

/**
 *
 * @author Microsoft
 */
public class Categoria {
    public static final String proteinaAnimal = "PROTEÍNA ANIMAL";
    public static final String proteinaNaoAnimal = "PROTEÍNA NÃO ANIMAL";
    public static final String derivadosLeite = "LEITE E DERIVADOS";
    public static final String bebidasAlcoolicas = "BEBIDAS ALCÓOLICAS";
    public static final String bebidasNaoAlcoolicas = "BEBIDAS NÃO ALCÓOLICAS";
}
